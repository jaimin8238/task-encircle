<?php
/** Shared header. @package CedarMillCo */
defined( 'ABSPATH' ) || exit;
$settings_id = cedarmillco_settings_id();
$logo        = cedarmillco_setting( 'cm_header_logo' );
$brand       = cedarmillco_setting( 'cm_brand_name' );
$top_bar     = cedarmillco_setting( 'cm_header_topbar' );
?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<a class="skip-link" href="#main-content"><?php esc_html_e( 'Skip to content', 'cedarmillco' ); ?></a>
<header class="site-header">
	<?php if ( $top_bar ) : ?><div class="topbar"><div class="header-container"><?php echo esc_html( $top_bar ); ?></div></div><?php endif; ?>
	<div class="header-container header-row">
		<?php if ( $logo || $brand ) : ?>
			<a class="brand" href="<?php echo esc_url( home_url( '/' ) ); ?>" aria-label="<?php echo esc_attr( $brand ? $brand : get_bloginfo( 'name' ) ); ?>">
				<?php if ( $logo ) { cedarmillco_image( $logo, 'medium', 'brand-logo', true ); } else { ?><span class="brand-name"><?php echo esc_html( $brand ); ?></span><?php if ( cedarmillco_setting( 'cm_header_tagline' ) ) : ?><span class="brand-tagline"><?php echo esc_html( cedarmillco_setting( 'cm_header_tagline' ) ); ?></span><?php endif; } ?>
			</a>
		<?php endif; ?>
		<?php if ( has_nav_menu( 'primary' ) ) : ?>
			<button class="menu-toggle" type="button" aria-controls="primary-navigation" aria-expanded="false"><?php esc_html_e( 'Menu', 'cedarmillco' ); ?><span aria-hidden="true">☰</span></button>
			<nav id="primary-navigation" class="primary-navigation" aria-label="<?php esc_attr_e( 'Main navigation', 'cedarmillco' ); ?>">
				<?php wp_nav_menu( array( 'theme_location' => 'primary', 'container' => false, 'menu_class' => 'main-menu', 'fallback_cb' => false, 'depth' => 0 ) ); ?>
			</nav>
		<?php endif; ?>
		<?php $buttons = cedarmillco_related( 'cm_header_buttons', $settings_id ); if ( $buttons ) : ?><div class="header-actions"><?php foreach ( $buttons as $item_id ) { cedarmillco_link( cedarmillco_field( 'cm_item_link', $item_id ), 'button button-small' ); } ?></div><?php endif; ?>
	</div>
</header>
