/* Accessible nested WordPress menus. No dependencies. */
(function () {
	'use strict';
	const header = document.querySelector('.site-header');
	if (!header) return;
	const mainToggle = header.querySelector('.menu-toggle');
	const nav = header.querySelector('.primary-navigation');
	if (!nav) return;
	const labels = window.cmNavLabels || { open: 'Open submenu', close: 'Close submenu' };
	const setMain = function (open) {
		header.classList.toggle('menu-open', open);
		if (mainToggle) mainToggle.setAttribute('aria-expanded', String(open));
	};
	if (mainToggle) mainToggle.addEventListener('click', function () { setMain(mainToggle.getAttribute('aria-expanded') !== 'true'); });
	nav.querySelectorAll('.menu-item-has-children').forEach(function (item, index) {
		const submenu = Array.from(item.children).find(function (child) { return child.classList.contains('sub-menu'); });
		if (!submenu) return;
		submenu.id = 'cm-submenu-' + index;
		const toggle = document.createElement('button');
		toggle.type = 'button';
		toggle.className = 'submenu-toggle';
		toggle.textContent = '+';
		toggle.setAttribute('aria-label', labels.open);
		toggle.setAttribute('aria-expanded', 'false');
		toggle.setAttribute('aria-controls', submenu.id);
		item.insertBefore(toggle, submenu);
		toggle.addEventListener('click', function () {
			const open = toggle.getAttribute('aria-expanded') !== 'true';
			item.classList.toggle('submenu-open', open);
			toggle.setAttribute('aria-expanded', String(open));
			toggle.setAttribute('aria-label', open ? labels.close : labels.open);
			toggle.textContent = open ? '−' : '+';
		});
	});
	const closeSubmenus = function () {
		nav.querySelectorAll('.submenu-open').forEach(function (item) { item.classList.remove('submenu-open'); });
		nav.querySelectorAll('.submenu-toggle').forEach(function (toggle) {
			toggle.setAttribute('aria-expanded', 'false'); toggle.setAttribute('aria-label', labels.open); toggle.textContent = '+';
		});
	};
	document.addEventListener('keydown', function (event) {
		if (event.key !== 'Escape') return;
		const active = document.activeElement;
		const parent = active && active.closest('.submenu-open');
		if (parent) {
			const toggle = Array.from(parent.children).find(function (child) { return child.classList.contains('submenu-toggle'); });
			parent.classList.remove('submenu-open');
			if (toggle) { toggle.setAttribute('aria-expanded', 'false'); toggle.setAttribute('aria-label', labels.open); toggle.textContent = '+'; toggle.focus(); }
		} else if (header.classList.contains('menu-open')) { setMain(false); if (mainToggle) mainToggle.focus(); }
	});
	document.addEventListener('click', function (event) { if (!header.contains(event.target)) { closeSubmenus(); setMain(false); } });
	window.matchMedia('(max-width: 1023px)').addEventListener('change', function () { closeSubmenus(); setMain(false); });
}());
