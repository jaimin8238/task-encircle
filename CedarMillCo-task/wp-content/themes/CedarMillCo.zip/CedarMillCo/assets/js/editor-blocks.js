/* Build-free native WordPress blocks backed by ACF Free section records. */
(function (wp, config) {
	'use strict';
	if (!wp || !config) return;
	const el = wp.element.createElement;
	const __ = wp.i18n.__;
	Object.keys(config.layouts).forEach(function (layout) {
		wp.blocks.registerBlockType('cedarmillco/' + layout, {
			apiVersion: 3,
			title: config.layouts[layout],
			category: 'cedarmillco',
			icon: 'layout',
			description: __('Displays a reusable Cedar section with content managed in ACF Free.', 'cedarmillco'),
			attributes: { sectionId: { type: 'integer', default: 0 } },
			supports: { html: false, reusable: false },
			edit: function (props) {
				const sections = config.sections.filter(function (item) { return item.layout === layout; });
				const selected = sections.find(function (item) { return item.id === props.attributes.sectionId; });
				const options = [{ label: __('Choose a published section…', 'cedarmillco'), value: 0 }].concat(sections.map(function (item) { return { label: item.title, value: item.id }; }));
				return el('div', wp.blockEditor.useBlockProps({ className: 'cm-editor-card' }),
					el('span', { className: 'cm-editor-badge' }, 'CedarMillCo · ACF Free'),
					el('h3', null, config.layouts[layout]),
					el(wp.components.SelectControl, { label: __('Section content', 'cedarmillco'), value: props.attributes.sectionId, options: options, onChange: function (value) { props.setAttributes({ sectionId: parseInt(value, 10) || 0 }); } }),
					el('p', null, __('Edit the content in Cedar Sections. Move or remove this block using the WordPress toolbar. Duplicated blocks share their selected section; duplicate the section record for independent content.', 'cedarmillco')),
					el(wp.components.Button, { href: selected ? selected.editUrl : config.newUrl, target: '_blank', rel: 'noopener noreferrer', variant: 'secondary' }, selected ? __('Edit ACF content ↗', 'cedarmillco') : __('Create section ↗', 'cedarmillco'))
				);
			},
			save: function () { return null; }
		});
	});
}(window.wp, window.cmBlockEditor));
