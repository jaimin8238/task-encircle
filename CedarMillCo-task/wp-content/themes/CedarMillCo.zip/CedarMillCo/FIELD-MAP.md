# CedarMillCo — Complete ACF field and block map

Fields are automatically registered when the theme and ACF Free are active. Do not manually recreate or import them. JSON files are provided for reference and portability. Content is stored in WordPress, not in the templates.

A “relationship” field is an ordered list: select existing published records on the left, then drag records on the right to set their order.


## Cedar Section — Layout

| Field label | Field name | Type |
|---|---|---|
| Section Layout | `cm_section_layout` | select |
| Hide This Section | `cm_section_hidden` | true_false |

## Cedar Section — 01 · Hero

| Field label | Field name | Type |
|---|---|---|
| Hero — Eyebrow | `cm_hero_eyebrow` | text |
| Hero — Heading | `cm_hero_heading` | text |
| Hero — Use H1 Heading | `cm_hero_primary_heading` | true_false |
| Hero — Supporting Text | `cm_hero_body` | textarea |
| Hero — Background Image | `cm_hero_image` | image |
| Hero — Buttons | `cm_hero_buttons` | relationship |

## Cedar Section — 02 · Intro Statement

| Field label | Field name | Type |
|---|---|---|
| Intro — Eyebrow | `cm_intro_eyebrow` | text |
| Intro — Heading | `cm_intro_heading` | text |
| Intro — Description | `cm_intro_body` | textarea |

## Cedar Section — 03 · Product Categories

| Field label | Field name | Type |
|---|---|---|
| Products — Eyebrow | `cm_products_eyebrow` | text |
| Products — Heading | `cm_products_heading` | textarea |
| Products — View All Link | `cm_products_link` | link |
| Products — Product Cards | `cm_products_cards` | relationship |

## Cedar Section — 04 · Every Detail — Value Propositions

| Field label | Field name | Type |
|---|---|---|
| Values — Eyebrow | `cm_values_eyebrow` | text |
| Values — Heading | `cm_values_heading` | text |
| Values — Description | `cm_values_body` | textarea |
| Values — Link | `cm_values_link` | link |
| Values — Value Propositions | `cm_values_items` | relationship |

## Cedar Section — 05 · Featured Project

| Field label | Field name | Type |
|---|---|---|
| Project — Eyebrow | `cm_project_eyebrow` | text |
| Project — Heading | `cm_project_heading` | text |
| Project — Description | `cm_project_body` | textarea |
| Project — Background Image | `cm_project_image` | image |
| Project — Button | `cm_project_link` | link |

## Cedar Section — 06 · CTA Band

| Field label | Field name | Type |
|---|---|---|
| CTA — Eyebrow | `cm_cta_eyebrow` | text |
| CTA — Heading | `cm_cta_heading` | text |
| CTA — Description | `cm_cta_body` | textarea |
| CTA — Button | `cm_cta_link` | link |

## Cedar Section — 07 · Newsletter

| Field label | Field name | Type |
|---|---|---|
| Newsletter — Heading | `cm_newsletter_heading` | text |
| Newsletter — Description | `cm_newsletter_body` | textarea |
| Newsletter — Enable Local Signup | `cm_newsletter_enabled` | true_false |
| Newsletter — Email Label / Placeholder | `cm_newsletter_email_label` | text |
| Newsletter — Button Label | `cm_newsletter_button_label` | text |
| Newsletter — Consent Label | `cm_newsletter_consent_label` | text |
| Newsletter — Success Message | `cm_newsletter_success` | text |
| Newsletter — Error Message | `cm_newsletter_error` | text |

## Cedar Section — 08 · Instagram Grid

| Field label | Field name | Type |
|---|---|---|
| Instagram — Heading | `cm_instagram_heading` | text |
| Instagram — Profile Link | `cm_instagram_link` | link |
| Instagram — Static Images | `cm_instagram_images` | relationship |
| Instagram — Caption | `cm_instagram_caption` | text |

## Cedar Homepage — Section Order

| Field label | Field name | Type |
|---|---|---|
| Homepage Editing Method | `cm_home_editor` | select |
| Homepage Sections — Drag to Reorder | `cm_home_sections` | relationship |

## Cedar Item — Content

| Field label | Field name | Type |
|---|---|---|
| Item Type | `cm_item_type` | select |
| Item — Heading | `cm_item_heading` | text |
| Item — Description / Address | `cm_item_description` | textarea |
| Item — Image | `cm_item_image` | image |
| Item — Link / Button | `cm_item_link` | link |
| Office — Phone Number | `cm_item_phone` | text |

## Cedar Site Settings — Header and Footer

| Field label | Field name | Type |
|---|---|---|
| Brand — Company Name | `cm_brand_name` | text |
| Header — Logo | `cm_header_logo` | image |
| Header — Logo Tagline | `cm_header_tagline` | text |
| Header — Top Bar Text | `cm_header_topbar` | text |
| Header — CTA Buttons | `cm_header_buttons` | relationship |
| Footer — Logo | `cm_footer_logo` | image |
| Footer — Tagline | `cm_footer_tagline` | text |
| Footer — Description | `cm_footer_description` | textarea |
| Footer — Contact Email | `cm_footer_email` | email |
| Footer — Contact Phone | `cm_footer_phone` | text |
| Footer — Social Links | `cm_footer_socials` | relationship |
| Footer — Office Locations | `cm_footer_offices` | relationship |
| Footer — Copyright | `cm_footer_copyright` | text |

## Native WordPress blocks

These use WordPress’s own block registration. They do not use the paid ACF Blocks feature. Each selects a published Cedar Section of the matching layout.

| Block title | Registered name | Template |
|---|---|---|
| 01 · Hero | `cedarmillco/hero` | `template-parts/sections/hero.php` |
| 02 · Intro Statement | `cedarmillco/intro` | `template-parts/sections/intro.php` |
| 03 · Product Categories | `cedarmillco/products` | `template-parts/sections/products.php` |
| 04 · Every Detail — Value Propositions | `cedarmillco/values` | `template-parts/sections/values.php` |
| 05 · Featured Project | `cedarmillco/project` | `template-parts/sections/project.php` |
| 06 · CTA Band | `cedarmillco/cta` | `template-parts/sections/cta.php` |
| 07 · Newsletter | `cedarmillco/newsletter` | `template-parts/sections/newsletter.php` |
| 08 · Instagram Grid | `cedarmillco/instagram` | `template-parts/sections/instagram.php` |

Duplicating a block creates another reference to the same section. To edit the copy independently, use **Cedar Sections → Duplicate**, publish the new section, then select that copy in the block. Reload the page editor after creating new section records.


## Free plugin design

There are no Flexible Content, Repeater, Gallery, Options Page, or ACF Blocks field APIs. Site Settings is one theme-managed WordPress record with ACF fields. Repeated cards, offices, social links and buttons use Cedar Items plus ordered Relationship fields. The number of items is not fixed.

