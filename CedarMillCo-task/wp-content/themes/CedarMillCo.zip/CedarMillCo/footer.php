<?php
/** Shared footer. @package CedarMillCo */
defined( 'ABSPATH' ) || exit;
$settings_id = cedarmillco_settings_id();
$brand       = cedarmillco_setting( 'cm_brand_name' );
$logo        = cedarmillco_setting( 'cm_footer_logo' );
?>
<footer class="site-footer">
	<div class="container footer-grid">
		<div class="footer-brand-column">
			<?php if ( $logo || $brand ) : ?><a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="footer-brand-name"><?php if ( $logo ) { cedarmillco_image( $logo, 'medium', 'footer-logo' ); } else { echo esc_html( $brand ); } ?></a><?php endif; ?>
			<?php cedarmillco_eyebrow( cedarmillco_setting( 'cm_footer_tagline' ) ); ?>
			<?php cedarmillco_rich_text( cedarmillco_setting( 'cm_footer_description' ) ); ?>
			<?php $email = sanitize_email( (string) cedarmillco_setting( 'cm_footer_email' ) ); if ( $email ) : ?><a href="<?php echo esc_url( 'mailto:' . $email ); ?>"><?php echo esc_html( $email ); ?></a><?php endif; ?>
			<?php $phone = (string) cedarmillco_setting( 'cm_footer_phone' ); if ( $phone ) : ?><a href="<?php echo esc_url( 'tel:' . preg_replace( '/[^0-9+]/', '', $phone ) ); ?>"><?php echo esc_html( $phone ); ?></a><?php endif; ?>
			<div class="social-links"><?php foreach ( cedarmillco_related( 'cm_footer_socials', $settings_id ) as $item_id ) { cedarmillco_link( cedarmillco_field( 'cm_item_link', $item_id ), 'social-link' ); } ?></div>
		</div>
		<?php foreach ( cedarmillco_related( 'cm_footer_offices', $settings_id ) as $item_id ) : ?>
			<div class="footer-office">
				<?php cedarmillco_heading( cedarmillco_text( 'cm_item_heading', $item_id ), 'h3' ); ?>
				<?php cedarmillco_rich_text( cedarmillco_field( 'cm_item_description', $item_id ) ); ?>
				<?php $phone = cedarmillco_text( 'cm_item_phone', $item_id ); if ( $phone ) : ?><a href="<?php echo esc_url( 'tel:' . preg_replace( '/[^0-9+]/', '', $phone ) ); ?>"><?php echo esc_html( $phone ); ?></a><?php endif; ?>
				<?php cedarmillco_link( cedarmillco_field( 'cm_item_link', $item_id ) ); ?>
			</div>
		<?php endforeach; ?>
	</div>
	<?php if ( has_nav_menu( 'footer' ) ) : ?><nav class="container footer-navigation" aria-label="<?php esc_attr_e( 'Footer navigation', 'cedarmillco' ); ?>"><?php wp_nav_menu( array( 'theme_location' => 'footer', 'container' => false, 'fallback_cb' => false ) ); ?></nav><?php endif; ?>
	<?php $copyright = cedarmillco_setting( 'cm_footer_copyright' ); if ( $copyright ) : ?><div class="container copyright"><?php echo esc_html( str_replace( '{year}', wp_date( 'Y' ), $copyright ) ); ?></div><?php endif; ?>
</footer>
<?php wp_footer(); ?>
</body>
</html>
