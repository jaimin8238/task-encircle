<?php
/** Blog and archive fallback. @package CedarMillCo */
defined( 'ABSPATH' ) || exit;
get_header();
?>
<main id="main-content" class="container page-content" tabindex="-1">
	<?php if ( have_posts() ) : ?>
		<?php if ( is_home() ) : ?><h1><?php echo esc_html( get_the_title( get_option( 'page_for_posts' ) ) ?: get_bloginfo( 'name' ) ); ?></h1><?php elseif ( is_search() ) : ?><h1><?php echo esc_html( get_search_query() ); ?></h1><?php elseif ( is_archive() ) : the_archive_title( '<h1>', '</h1>' ); endif; ?>
		<?php while ( have_posts() ) : the_post(); ?>
			<article <?php post_class( 'archive-entry' ); ?>>
				<h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
				<?php if ( is_singular() ) { the_content(); wp_link_pages(); } else { the_excerpt(); } ?>
			</article>
		<?php endwhile; the_posts_pagination(); ?>
	<?php else : ?><p><?php esc_html_e( 'No content found.', 'cedarmillco' ); ?></p><?php endif; ?>
</main>
<?php get_footer(); ?>
