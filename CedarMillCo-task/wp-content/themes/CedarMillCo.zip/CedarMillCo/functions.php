<?php
/** Theme bootstrap. @package CedarMillCo */
defined( 'ABSPATH' ) || exit;

define( 'CEDARMILLCO_VERSION', '1.0.0' );

foreach ( array( 'setup', 'helpers', 'content', 'fields', 'blocks', 'newsletter', 'admin', 'starter' ) as $cm_module ) {
	require_once get_template_directory() . '/inc/' . $cm_module . '.php';
}
