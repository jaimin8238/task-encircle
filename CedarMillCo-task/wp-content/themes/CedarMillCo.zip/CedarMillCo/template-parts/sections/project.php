<?php
/** Featured project. @package CedarMillCo */
defined( 'ABSPATH' ) || exit;
$id      = absint( $args['section_id'] ?? 0 );
$heading = cedarmillco_text( 'cm_project_heading', $id );
$eyebrow = cedarmillco_text( 'cm_project_eyebrow', $id );
$body    = cedarmillco_text( 'cm_project_body', $id );
$image   = cedarmillco_field( 'cm_project_image', $id );
$link    = cedarmillco_field( 'cm_project_link', $id );
if ( ! $heading && ! $eyebrow && ! $body && ! $image && ! $link ) { return; }
?>
<section class="image-section featured-project<?php echo $image ? '' : ' no-image'; ?>">
	<?php cedarmillco_image( $image, 'full', 'section-image' ); ?>
	<div class="container image-section-inner"><div class="image-panel project-panel">
		<?php cedarmillco_eyebrow( $eyebrow ); cedarmillco_heading( $heading ); cedarmillco_rich_text( $body ); cedarmillco_link( $link, 'button button-outline' ); ?>
	</div></div>
</section>
