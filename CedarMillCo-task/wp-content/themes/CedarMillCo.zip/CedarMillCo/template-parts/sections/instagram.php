<?php
/** Static Instagram grid, no remote feed. @package CedarMillCo */
defined( 'ABSPATH' ) || exit;
$id      = absint( $args['section_id'] ?? 0 );
$heading = cedarmillco_text( 'cm_instagram_heading', $id );
$link    = cedarmillco_field( 'cm_instagram_link', $id );
$caption = cedarmillco_text( 'cm_instagram_caption', $id );
$items   = cedarmillco_related( 'cm_instagram_images', $id );
if ( ! $heading && ! $link && ! $caption && ! $items ) { return; }
?>
<section class="section instagram"><div class="container">
	<div class="section-heading"><?php cedarmillco_heading( $heading ); cedarmillco_link( $link ); ?></div>
	<?php if ( $items ) : ?><div class="instagram-grid">
		<?php foreach ( $items as $item_id ) : $image = cedarmillco_field( 'cm_item_image', $item_id ); if ( ! $image ) { continue; } $link = cedarmillco_field( 'cm_item_link', $item_id ); ?>
			<div class="instagram-tile">
				<?php if ( is_array( $link ) && ! empty( $link['url'] ) && ! empty( $link['title'] ) && esc_url( $link['url'] ) ) : ?><a href="<?php echo esc_url( $link['url'] ); ?>" aria-label="<?php echo esc_attr( $link['title'] ); ?>"<?php if ( '_blank' === ( $link['target'] ?? '' ) ) : ?> target="_blank" rel="noopener noreferrer"<?php endif; ?>><?php cedarmillco_image( $image, 'cm-card' ); ?></a><?php else : cedarmillco_image( $image, 'cm-card' ); endif; ?>
			</div>
		<?php endforeach; ?>
	</div><?php endif; ?>
	<?php if ( $caption ) : ?><p class="grid-caption"><?php echo esc_html( $caption ); ?></p><?php endif; ?>
</div></section>
