<?php
/** Intro statement. @package CedarMillCo */
defined( 'ABSPATH' ) || exit;
$id      = absint( $args['section_id'] ?? 0 );
$heading = cedarmillco_text( 'cm_intro_heading', $id );
$eyebrow = cedarmillco_text( 'cm_intro_eyebrow', $id );
$body    = cedarmillco_text( 'cm_intro_body', $id );
if ( ! $heading && ! $eyebrow && ! $body ) { return; }
?>
<section class="section intro"><div class="container two-column">
	<div><?php cedarmillco_eyebrow( $eyebrow ); cedarmillco_heading( $heading ); ?></div>
	<?php cedarmillco_rich_text( $body ); ?>
</div></section>
