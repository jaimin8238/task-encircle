<?php
/** Local newsletter opt-in. @package CedarMillCo */
defined( 'ABSPATH' ) || exit;
$id      = absint( $args['section_id'] ?? 0 );
$heading = cedarmillco_text( 'cm_newsletter_heading', $id );
$body    = cedarmillco_text( 'cm_newsletter_body', $id );
$enabled = cedarmillco_field( 'cm_newsletter_enabled', $id );
if ( ! $heading && ! $body && ! $enabled ) { return; }
$uid = wp_unique_id( 'cm-newsletter-' );
$email_label = cedarmillco_text( 'cm_newsletter_email_label', $id );
$button_label = cedarmillco_text( 'cm_newsletter_button_label', $id );
$consent_label = cedarmillco_text( 'cm_newsletter_consent_label', $id );
$status = isset( $_GET['cm_signup'] ) ? sanitize_key( wp_unslash( $_GET['cm_signup'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
?>
<section class="newsletter"><div class="container"><div class="newsletter-inner">
	<div><?php cedarmillco_heading( $heading ); cedarmillco_rich_text( $body ); ?></div>
	<?php if ( $enabled && $email_label && $button_label && $consent_label ) : ?>
		<form class="newsletter-form" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" method="post">
			<input type="hidden" name="action" value="cedarmillco_subscribe">
			<input type="hidden" name="section_id" value="<?php echo esc_attr( $id ); ?>">
			<?php wp_nonce_field( 'cedarmillco_subscribe_' . $id, 'cm_subscribe_nonce', false ); ?>
			<div class="newsletter-fields"><label class="screen-reader-text" for="<?php echo esc_attr( $uid ); ?>"><?php echo esc_html( $email_label ); ?></label>
			<input type="email" id="<?php echo esc_attr( $uid ); ?>" name="cm_email" autocomplete="email" maxlength="254" placeholder="<?php echo esc_attr( $email_label ); ?>" required>
			<button type="submit" class="button"><?php echo esc_html( $button_label ); ?></button></div>
			<label class="newsletter-consent"><input type="checkbox" name="cm_consent" value="1" required><span><?php echo esc_html( $consent_label ); ?></span></label>
			<div class="cm-honeypot" aria-hidden="true"><label><?php esc_html_e( 'Leave this empty', 'cedarmillco' ); ?><input type="text" name="cm_website" tabindex="-1" autocomplete="off"></label></div>
			<?php if ( $status ) : ?><p class="form-message" role="status"><?php echo esc_html( cedarmillco_text( 'success' === $status ? 'cm_newsletter_success' : 'cm_newsletter_error', $id ) ); ?></p><?php endif; ?>
		</form>
	<?php endif; ?>
</div></div></section>
