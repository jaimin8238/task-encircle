<?php
/** Hero section. @package CedarMillCo */
defined( 'ABSPATH' ) || exit;
$id      = absint( $args['section_id'] ?? 0 );
$heading = cedarmillco_text( 'cm_hero_heading', $id );
$image   = cedarmillco_field( 'cm_hero_image', $id );
$body    = cedarmillco_text( 'cm_hero_body', $id );
$eyebrow = cedarmillco_text( 'cm_hero_eyebrow', $id );
$buttons = cedarmillco_related( 'cm_hero_buttons', $id );
if ( ! $heading && ! $image && ! $body && ! $eyebrow && ! $buttons ) { return; }
$tag = cedarmillco_field( 'cm_hero_primary_heading', $id ) ? 'h1' : 'h2';
?>
<section class="image-section hero<?php echo $image ? '' : ' no-image'; ?>">
	<?php cedarmillco_image( $image, 'full', 'section-image', true ); ?>
	<div class="container image-section-inner">
		<?php if ( $heading || $body || $eyebrow || $buttons ) : ?><div class="image-panel hero-panel">
			<?php cedarmillco_eyebrow( $eyebrow ); cedarmillco_heading( $heading, $tag ); cedarmillco_rich_text( $body ); ?>
			<?php if ( $buttons ) : ?><div class="button-row"><?php foreach ( $buttons as $index => $item_id ) { cedarmillco_link( cedarmillco_field( 'cm_item_link', $item_id ), $index ? 'button button-outline' : 'button' ); } ?></div><?php endif; ?>
		</div><?php endif; ?>
	</div>
</section>
