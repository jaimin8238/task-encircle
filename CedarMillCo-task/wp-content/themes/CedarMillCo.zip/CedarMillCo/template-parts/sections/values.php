<?php
/** Value propositions. @package CedarMillCo */
defined( 'ABSPATH' ) || exit;
$id      = absint( $args['section_id'] ?? 0 );
$heading = cedarmillco_text( 'cm_values_heading', $id );
$eyebrow = cedarmillco_text( 'cm_values_eyebrow', $id );
$body    = cedarmillco_text( 'cm_values_body', $id );
$link    = cedarmillco_field( 'cm_values_link', $id );
$items   = cedarmillco_related( 'cm_values_items', $id );
if ( ! $heading && ! $eyebrow && ! $body && ! $link && ! $items ) { return; }
?>
<section class="section values"><div class="container values-grid">
	<div><?php cedarmillco_eyebrow( $eyebrow ); cedarmillco_heading( $heading ); cedarmillco_rich_text( $body ); cedarmillco_link( $link ); ?></div>
	<?php if ( $items ) : ?><div class="value-list"><?php foreach ( $items as $item_id ) : ?>
		<?php $title = cedarmillco_text( 'cm_item_heading', $item_id ); $description = cedarmillco_text( 'cm_item_description', $item_id ); if ( ! $title && ! $description ) { continue; } ?>
		<div class="value-item"><?php cedarmillco_heading( $title, 'h3' ); cedarmillco_rich_text( $description ); ?></div>
	<?php endforeach; ?></div><?php endif; ?>
</div></section>
