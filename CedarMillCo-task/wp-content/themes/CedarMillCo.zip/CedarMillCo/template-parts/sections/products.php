<?php
/** Product categories. @package CedarMillCo */
defined( 'ABSPATH' ) || exit;
$id      = absint( $args['section_id'] ?? 0 );
$heading = cedarmillco_text( 'cm_products_heading', $id );
$eyebrow = cedarmillco_text( 'cm_products_eyebrow', $id );
$link    = cedarmillco_field( 'cm_products_link', $id );
$items   = cedarmillco_related( 'cm_products_cards', $id );
if ( ! $heading && ! $eyebrow && ! $link && ! $items ) { return; }
?>
<section class="section products"><div class="container">
	<div class="section-heading"><div><?php cedarmillco_eyebrow( $eyebrow ); cedarmillco_heading( $heading ); ?></div><?php cedarmillco_link( $link ); ?></div>
	<?php if ( $items ) : ?><div class="product-grid">
		<?php foreach ( $items as $item_id ) :
			$title = cedarmillco_text( 'cm_item_heading', $item_id );
			$description = cedarmillco_text( 'cm_item_description', $item_id );
			$image = cedarmillco_field( 'cm_item_image', $item_id );
			$link = cedarmillco_field( 'cm_item_link', $item_id );
			if ( ! $title && ! $description && ! $image ) { continue; }
			$linked = is_array( $link ) && ! empty( $link['url'] ) && esc_url( $link['url'] ) && $title;
			?>
			<article class="product-card<?php echo $image ? '' : ' no-image'; ?>">
				<?php cedarmillco_image( $image, 'cm-card', 'card-image' ); ?>
				<div class="card-caption">
					<?php if ( $title ) : ?><h3><?php if ( $linked ) : ?><a class="stretched-link" href="<?php echo esc_url( $link['url'] ); ?>"<?php if ( '_blank' === ( $link['target'] ?? '' ) ) : ?> target="_blank" rel="noopener noreferrer"<?php endif; ?>><?php echo esc_html( $title ); ?></a><?php else : echo esc_html( $title ); endif; ?></h3><?php endif; ?>
					<?php if ( $description ) : ?><p><?php echo esc_html( $description ); ?></p><?php endif; ?>
				</div>
			</article>
		<?php endforeach; ?>
	</div><?php endif; ?>
</div></section>
