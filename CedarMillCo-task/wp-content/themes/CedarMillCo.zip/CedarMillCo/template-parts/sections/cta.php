<?php
/** CTA band. @package CedarMillCo */
defined( 'ABSPATH' ) || exit;
$id      = absint( $args['section_id'] ?? 0 );
$heading = cedarmillco_text( 'cm_cta_heading', $id );
$eyebrow = cedarmillco_text( 'cm_cta_eyebrow', $id );
$body    = cedarmillco_text( 'cm_cta_body', $id );
$link    = cedarmillco_field( 'cm_cta_link', $id );
if ( ! $heading && ! $eyebrow && ! $body && ! $link ) { return; }
?>
<section class="section cta-band"><div class="container cta-grid">
	<div><?php cedarmillco_eyebrow( $eyebrow ); cedarmillco_heading( $heading ); cedarmillco_rich_text( $body ); ?></div>
	<?php cedarmillco_link( $link, 'button' ); ?>
</div></section>
