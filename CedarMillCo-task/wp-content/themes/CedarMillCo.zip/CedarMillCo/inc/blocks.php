<?php
/** Native WordPress blocks; no ACF Blocks/Pro APIs. @package CedarMillCo */
defined( 'ABSPATH' ) || exit;

function cedarmillco_register_blocks() {
	wp_register_script( 'cedarmillco-editor', get_theme_file_uri( '/assets/js/editor-blocks.js' ), array( 'wp-blocks', 'wp-element', 'wp-components', 'wp-block-editor', 'wp-i18n' ), CEDARMILLCO_VERSION, true );
	foreach ( array_keys( cedarmillco_layouts() ) as $layout ) {
		register_block_type( get_template_directory() . '/blocks/' . $layout, array(
			'render_callback' => static function ( $attributes ) use ( $layout ) {
				ob_start();
				cedarmillco_render_section( absint( $attributes['sectionId'] ?? 0 ), $layout );
				return ob_get_clean();
			},
		) );
	}
}
add_action( 'init', 'cedarmillco_register_blocks' );

function cedarmillco_block_category( $categories ) {
	$categories[] = array( 'slug' => 'cedarmillco', 'title' => __( 'Cedar Mill Co.', 'cedarmillco' ) );
	return $categories;
}
add_filter( 'block_categories_all', 'cedarmillco_block_category' );

function cedarmillco_editor_data() {
	$sections = array();
	foreach ( get_posts( array( 'post_type' => 'cm_section', 'post_status' => 'publish', 'numberposts' => -1, 'orderby' => 'title', 'order' => 'ASC' ) ) as $section ) {
		$sections[] = array( 'id' => $section->ID, 'title' => $section->post_title, 'layout' => cedarmillco_text( 'cm_section_layout', $section->ID ), 'editUrl' => get_edit_post_link( $section->ID, 'raw' ) );
	}
	wp_add_inline_script( 'cedarmillco-editor', 'window.cmBlockEditor = ' . wp_json_encode( array( 'layouts' => cedarmillco_layouts(), 'sections' => $sections, 'newUrl' => admin_url( 'post-new.php?post_type=cm_section' ) ) ) . ';', 'before' );
}
add_action( 'enqueue_block_editor_assets', 'cedarmillco_editor_data' );
