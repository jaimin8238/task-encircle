<?php
/** Reusable content entities, compatible with ACF Free. @package CedarMillCo */
defined( 'ABSPATH' ) || exit;

function cedarmillco_content_types() {
	register_post_type( 'cm_section', array(
		'labels' => array( 'name' => __( 'Cedar Sections', 'cedarmillco' ), 'singular_name' => __( 'Cedar Section', 'cedarmillco' ), 'add_new_item' => __( 'Add Cedar Section', 'cedarmillco' ), 'edit_item' => __( 'Edit Cedar Section', 'cedarmillco' ) ),
		'public' => false, 'show_ui' => true, 'show_in_rest' => false, 'menu_icon' => 'dashicons-layout',
		'supports' => array( 'title', 'revisions' ), 'capability_type' => 'page', 'map_meta_cap' => true,
	) );
	register_post_type( 'cm_item', array(
		'labels' => array( 'name' => __( 'Cedar Items', 'cedarmillco' ), 'singular_name' => __( 'Cedar Item', 'cedarmillco' ), 'add_new_item' => __( 'Add Cedar Item', 'cedarmillco' ), 'edit_item' => __( 'Edit Cedar Item', 'cedarmillco' ) ),
		'public' => false, 'show_ui' => true, 'show_in_rest' => false, 'menu_icon' => 'dashicons-screenoptions',
		'supports' => array( 'title', 'revisions' ), 'capability_type' => 'page', 'map_meta_cap' => true,
	) );
	$admin_caps = array_fill_keys( array( 'edit_post', 'read_post', 'delete_post', 'edit_posts', 'edit_others_posts', 'publish_posts', 'read_private_posts', 'delete_posts', 'delete_private_posts', 'delete_published_posts', 'delete_others_posts', 'edit_private_posts', 'edit_published_posts', 'create_posts' ), 'manage_options' );
	register_post_type( 'cm_settings', array(
		'labels' => array( 'name' => __( 'Cedar Site Settings', 'cedarmillco' ), 'singular_name' => __( 'Cedar Site Settings', 'cedarmillco' ) ),
		'public' => false, 'show_ui' => true, 'show_in_menu' => false, 'show_in_rest' => false,
		'supports' => array( 'title' ), 'capabilities' => $admin_caps, 'map_meta_cap' => false,
	) );
	register_post_type( 'cm_subscriber', array(
		'labels' => array( 'name' => __( 'Newsletter Subscribers', 'cedarmillco' ), 'singular_name' => __( 'Newsletter Subscriber', 'cedarmillco' ) ),
		'public' => false, 'show_ui' => true, 'show_in_rest' => false, 'menu_icon' => 'dashicons-email',
		'supports' => array( 'title' ), 'capabilities' => $admin_caps, 'map_meta_cap' => false,
	) );
}
add_action( 'init', 'cedarmillco_content_types' );

function cedarmillco_relationship_query( $args, $field ) {
	$types = array(
		'cm_header_buttons' => 'button', 'cm_footer_socials' => 'social', 'cm_footer_offices' => 'office',
		'cm_hero_buttons' => 'button', 'cm_products_cards' => 'product', 'cm_values_items' => 'value', 'cm_instagram_images' => 'instagram',
	);
	if ( isset( $types[ $field['name'] ] ) ) {
		$args['meta_query'][] = array( 'key' => 'cm_item_type', 'value' => $types[ $field['name'] ] );
	}
	$args['post_status'] = 'publish';
	return $args;
}
add_filter( 'acf/fields/relationship/query', 'cedarmillco_relationship_query', 10, 2 );
