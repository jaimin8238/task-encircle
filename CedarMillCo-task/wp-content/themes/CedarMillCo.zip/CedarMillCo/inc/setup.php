<?php
/** WordPress integration. @package CedarMillCo */
defined( 'ABSPATH' ) || exit;

function cedarmillco_setup() {
	load_theme_textdomain( 'cedarmillco', get_template_directory() . '/languages' );
	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'responsive-embeds' );
	add_theme_support( 'align-wide' );
	add_theme_support( 'editor-styles' );
	add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script', 'navigation-widgets' ) );
	add_editor_style( 'assets/css/editor.css' );
	register_nav_menus( array( 'primary' => __( 'Main Navigation', 'cedarmillco' ), 'footer' => __( 'Footer Navigation', 'cedarmillco' ) ) );
	add_image_size( 'cm-card', 900, 1100, true );
	add_image_size( 'cm-wide', 2200, 1200, false );
}
add_action( 'after_setup_theme', 'cedarmillco_setup' );

function cedarmillco_assets() {
	wp_enqueue_style( 'cedarmillco-fonts', get_theme_file_uri( '/assets/css/fonts.css' ), array(), CEDARMILLCO_VERSION );
	wp_enqueue_style( 'cedarmillco-reference', get_theme_file_uri( '/assets/css/reference.css' ), array( 'cedarmillco-fonts' ), CEDARMILLCO_VERSION );
	wp_enqueue_style( 'cedarmillco', get_theme_file_uri( '/assets/css/main.css' ), array( 'cedarmillco-reference' ), CEDARMILLCO_VERSION );
	wp_enqueue_script( 'cedarmillco', get_theme_file_uri( '/assets/js/main.js' ), array(), CEDARMILLCO_VERSION, true );
	wp_add_inline_script( 'cedarmillco', 'window.cmNavLabels = ' . wp_json_encode( array( 'open' => __( 'Open submenu', 'cedarmillco' ), 'close' => __( 'Close submenu', 'cedarmillco' ) ) ) . ';', 'before' );
}
add_action( 'wp_enqueue_scripts', 'cedarmillco_assets' );

function cedarmillco_body_classes( $classes ) {
	$classes[] = 'cedarmillco';
	return $classes;
}
add_filter( 'body_class', 'cedarmillco_body_classes' );
