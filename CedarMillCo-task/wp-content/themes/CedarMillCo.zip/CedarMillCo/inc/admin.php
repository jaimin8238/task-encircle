<?php
/** Setup screen, settings shortcut and duplicate controls. @package CedarMillCo */
defined( 'ABSPATH' ) || exit;

function cedarmillco_admin_menu() {
	add_theme_page( __( 'Cedar Mill Setup', 'cedarmillco' ), __( 'Cedar Mill Setup', 'cedarmillco' ), 'manage_options', 'cedarmillco-setup', 'cedarmillco_setup_screen' );
	$id = cedarmillco_settings_id();
	add_menu_page( __( 'Cedar Site Settings', 'cedarmillco' ), __( 'Cedar Site Settings', 'cedarmillco' ), 'manage_options', $id ? 'post.php?post=' . $id . '&action=edit' : 'themes.php?page=cedarmillco-setup', '', 'dashicons-admin-settings', 59 );
}
add_action( 'admin_menu', 'cedarmillco_admin_menu' );

function cedarmillco_notice() {
	if ( ! current_user_can( 'manage_options' ) ) { return; }
	if ( ! function_exists( 'get_field' ) ) {
		echo '<div class="notice notice-error"><p>' . esc_html__( 'CedarMillCo needs Advanced Custom Fields (free). Install and activate it under Plugins → Add New, then open Appearance → Cedar Mill Setup. ACF Pro is not required.', 'cedarmillco' ) . '</p></div>';
	} elseif ( ! get_option( 'cedarmillco_starter_installed' ) ) {
		echo '<div class="notice notice-info"><p><a href="' . esc_url( admin_url( 'themes.php?page=cedarmillco-setup' ) ) . '">' . esc_html__( 'Finish CedarMillCo setup', 'cedarmillco' ) . '</a></p></div>';
	}
}
add_action( 'admin_notices', 'cedarmillco_notice' );

function cedarmillco_setup_screen() {
	if ( ! current_user_can( 'manage_options' ) ) { return; }
	?>
	<div class="wrap" style="max-width:900px">
		<h1><?php esc_html_e( 'CedarMillCo — Setup', 'cedarmillco' ); ?></h1>
		<p><?php esc_html_e( 'This custom theme works with ACF Free. It includes eight section layouts and eight native WordPress blocks. All fields register automatically.', 'cedarmillco' ); ?></p>
		<?php if ( ! function_exists( 'update_field' ) ) : ?>
			<p><strong><?php esc_html_e( 'First install and activate Advanced Custom Fields (free), then return here.', 'cedarmillco' ); ?></strong></p>
		<?php elseif ( get_option( 'cedarmillco_starter_installed' ) ) : ?>
			<div class="notice notice-success inline"><p><?php esc_html_e( 'Starter content is installed. Edit Cedar Sections, Cedar Items and Cedar Site Settings. Re-running setup is disabled to protect your edits.', 'cedarmillco' ); ?></p></div>
			<p><a class="button button-primary" href="<?php echo esc_url( get_edit_post_link( cedarmillco_settings_id(), 'raw' ) ); ?>"><?php esc_html_e( 'Edit Header and Footer', 'cedarmillco' ); ?></a> <a class="button" href="<?php echo esc_url( get_edit_post_link( absint( get_option( 'cedarmillco_home_id' ) ), 'raw' ) ); ?>"><?php esc_html_e( 'Edit Homepage Order', 'cedarmillco' ); ?></a></p>
		<?php else : ?>
			<h2><?php esc_html_e( 'Create editable starter content', 'cedarmillco' ); ?></h2>
			<p><?php esc_html_e( 'Creates the homepage, eight sections, reusable items, shared settings, placeholder destination pages, a nested menu and original homepage images from the supplied design reference. Review destination-page content and contact details before launch.', 'cedarmillco' ); ?></p>
			<?php if ( get_option( 'cedarmillco_setup_error' ) ) : ?><div class="notice notice-error inline"><p><?php echo esc_html( get_option( 'cedarmillco_setup_error' ) ); ?></p></div><?php endif; ?>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="cedarmillco_install_starter">
				<?php wp_nonce_field( 'cedarmillco_install_starter' ); ?>
				<p><label><input type="checkbox" name="cm_set_home" value="1" checked> <?php esc_html_e( 'Set the new Cedar Mill page as my site homepage. This changes Settings → Reading.', 'cedarmillco' ); ?></label></p>
				<p><label><input type="checkbox" name="cm_set_menu" value="1" checked> <?php esc_html_e( 'Assign the new nested Cedar Mill menu to Main Navigation. My existing menus are preserved.', 'cedarmillco' ); ?></label></p>
				<?php submit_button( __( 'Create Starter Site', 'cedarmillco' ) ); ?>
			</form>
		<?php endif; ?>
		<h2><?php esc_html_e( 'Where to edit', 'cedarmillco' ); ?></h2>
		<ol>
			<li><?php esc_html_e( 'Cedar Site Settings: company name, header, footer, contacts and selected offices/social links.', 'cedarmillco' ); ?></li>
			<li><?php esc_html_e( 'Cedar Sections: edit the content of each homepage section. Use Duplicate in the list for independent copies.', 'cedarmillco' ); ?></li>
			<li><?php esc_html_e( 'Cedar Items: product cards, value propositions, office locations, social links, images and CTA buttons.', 'cedarmillco' ); ?></li>
			<li><?php esc_html_e( 'Pages → your homepage: choose and reorder sections in the ACF list. Alternatively select Native WordPress blocks and use the Cedar Mill Co. block category.', 'cedarmillco' ); ?></li>
			<li><?php esc_html_e( 'Appearance → Menus: edit Main Navigation. Indent items beneath Products or Projects to create dropdowns.', 'cedarmillco' ); ?></li>
			<li><?php esc_html_e( 'Newsletter Subscribers: privately stored opt-ins. No email campaigns are sent by this theme.', 'cedarmillco' ); ?></li>
		</ol>
		<p><?php esc_html_e( 'The full beginner setup guide and field map are included in the theme folder.', 'cedarmillco' ); ?></p>
	</div>
	<?php
}

function cedarmillco_duplicate_link( $actions, $post ) {
	if ( in_array( $post->post_type, array( 'cm_section', 'cm_item' ), true ) && current_user_can( 'edit_post', $post->ID ) ) {
		$url = wp_nonce_url( admin_url( 'admin-post.php?action=cedarmillco_duplicate&post=' . $post->ID ), 'cedarmillco_duplicate_' . $post->ID );
		$actions['cm_duplicate'] = '<a href="' . esc_url( $url ) . '">' . esc_html__( 'Duplicate', 'cedarmillco' ) . '</a>';
	}
	return $actions;
}
add_filter( 'post_row_actions', 'cedarmillco_duplicate_link', 10, 2 );

function cedarmillco_duplicate() {
	$id = isset( $_GET['post'] ) && is_scalar( $_GET['post'] ) ? absint( $_GET['post'] ) : 0;
	check_admin_referer( 'cedarmillco_duplicate_' . $id );
	$source = get_post( $id );
	if ( ! $source || ! in_array( $source->post_type, array( 'cm_section', 'cm_item' ), true ) || ! current_user_can( 'edit_post', $id ) || ! current_user_can( 'edit_pages' ) ) {
		wp_die( esc_html__( 'You cannot duplicate this record.', 'cedarmillco' ) );
	}
	$copy = wp_insert_post( wp_slash( array( 'post_type' => $source->post_type, 'post_title' => $source->post_title . ' — ' . __( 'Copy', 'cedarmillco' ), 'post_status' => 'draft', 'post_author' => get_current_user_id() ) ), true );
	if ( is_wp_error( $copy ) ) { wp_die( esc_html( $copy->get_error_message() ) ); }
	foreach ( get_post_meta( $id ) as $key => $values ) {
		if ( in_array( $key, array( '_edit_lock', '_edit_last', '_cm_starter_key' ), true ) ) { continue; }
		foreach ( $values as $value ) { add_post_meta( $copy, $key, wp_slash( maybe_unserialize( $value ) ) ); }
	}
	wp_safe_redirect( get_edit_post_link( $copy, 'raw' ) );
	exit;
}
add_action( 'admin_post_cedarmillco_duplicate', 'cedarmillco_duplicate' );

function cedarmillco_content_columns( $columns ) {
	$columns['cm_type'] = __( 'Cedar Type', 'cedarmillco' );
	return $columns;
}
add_filter( 'manage_cm_section_posts_columns', 'cedarmillco_content_columns' );
add_filter( 'manage_cm_item_posts_columns', 'cedarmillco_content_columns' );

function cedarmillco_content_column( $column, $id ) {
	if ( 'cm_type' === $column ) {
		$value = cedarmillco_text( 'cm_section' === get_post_type( $id ) ? 'cm_section_layout' : 'cm_item_type', $id );
		echo esc_html( ucwords( str_replace( '_', ' ', $value ) ) );
	}
}
add_action( 'manage_cm_section_posts_custom_column', 'cedarmillco_content_column', 10, 2 );
add_action( 'manage_cm_item_posts_custom_column', 'cedarmillco_content_column', 10, 2 );
