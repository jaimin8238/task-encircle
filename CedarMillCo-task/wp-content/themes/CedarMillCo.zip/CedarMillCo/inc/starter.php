<?php
/** Explicit, repeat-safe starter installer. Never runs on theme activation. @package CedarMillCo */
defined( 'ABSPATH' ) || exit;

function cedarmillco_seed_post( $type, $title, $key, $fields = array(), $extra = array() ) {
	$existing = get_posts( array( 'post_type' => $type, 'post_status' => array( 'publish', 'draft', 'private', 'pending' ), 'meta_key' => '_cm_starter_key', 'meta_value' => $key, 'numberposts' => 1, 'fields' => 'ids' ) );
	if ( $existing ) { return $existing[0]; }
	$id = wp_insert_post( wp_slash( array_merge( array( 'post_type' => $type, 'post_title' => $title, 'post_status' => 'publish', 'meta_input' => array( '_cm_starter_key' => $key ) ), $extra ) ), true );
	if ( is_wp_error( $id ) ) { throw new RuntimeException( $id->get_error_message() ); }
	foreach ( $fields as $name => $value ) {
		update_field( 'field_' . $name, $value, $id );
	}
	return $id;
}

function cedarmillco_seed_resolve( $value, $refs ) {
	if ( is_array( $value ) ) {
		foreach ( $value as $key => $child ) { $value[ $key ] = cedarmillco_seed_resolve( $child, $refs ); }
		return $value;
	}
	if ( is_string( $value ) && isset( $refs[ $value ] ) ) { return $refs[ $value ]; }
	return $value;
}

function cedarmillco_install_starter() {
	if ( ! current_user_can( 'manage_options' ) ) { wp_die( esc_html__( 'Administrator access required.', 'cedarmillco' ) ); }
	check_admin_referer( 'cedarmillco_install_starter' );
	if ( ! function_exists( 'update_field' ) ) { wp_die( esc_html__( 'Activate ACF Free first.', 'cedarmillco' ) ); }
	if ( get_option( 'cedarmillco_starter_installed' ) ) {
		wp_safe_redirect( admin_url( 'themes.php?page=cedarmillco-setup' ) );
		exit;
	}
	if ( ! add_option( 'cedarmillco_setup_lock', time(), '', false ) ) {
		if ( (int) get_option( 'cedarmillco_setup_lock' ) > time() - 300 ) { wp_die( esc_html__( 'Setup is already running. Wait a moment, then refresh.', 'cedarmillco' ) ); }
		delete_option( 'cedarmillco_setup_lock' );
		add_option( 'cedarmillco_setup_lock', time(), '', false );
	}
	try {
		$result = cedarmillco_create_starter_content( ! empty( $_POST['cm_set_home'] ), ! empty( $_POST['cm_set_menu'] ) );
		if ( $result ) {
			update_option( 'cedarmillco_starter_installed', 1, false );
			delete_option( 'cedarmillco_setup_error' );
		}
	} catch ( Throwable $error ) {
		update_option( 'cedarmillco_setup_error', sanitize_text_field( $error->getMessage() ), false );
	}
	delete_option( 'cedarmillco_setup_lock' );
	wp_safe_redirect( admin_url( 'themes.php?page=cedarmillco-setup' ) );
	exit;
}
add_action( 'admin_post_cedarmillco_install_starter', 'cedarmillco_install_starter' );

function cedarmillco_create_starter_content( $set_home = false, $set_menu = false ) {
	$data = json_decode( file_get_contents( get_template_directory() . '/inc/starter-content.json' ), true ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
	if ( ! is_array( $data ) || empty( $data['sections'] ) ) { throw new RuntimeException( __( 'Starter content is missing or invalid.', 'cedarmillco' ) ); }
	require_once ABSPATH . 'wp-admin/includes/file.php';
	require_once ABSPATH . 'wp-admin/includes/media.php';
	require_once ABSPATH . 'wp-admin/includes/image.php';
	$refs = array();
	foreach ( $data['images'] as $image ) {
		$key = 'image-' . sanitize_key( $image['key'] );
		$existing = get_posts( array( 'post_type' => 'attachment', 'post_status' => 'inherit', 'meta_key' => '_cm_starter_key', 'meta_value' => $key, 'numberposts' => 1, 'fields' => 'ids' ) );
		if ( $existing ) { $id = $existing[0]; } else {
			$file = get_template_directory() . '/assets/images/' . sanitize_file_name( $image['file'] );
			if ( ! is_readable( $file ) ) { throw new RuntimeException( __( 'A bundled starter image is missing.', 'cedarmillco' ) ); }
			$temp = wp_tempnam( $image['file'] );
			if ( ! $temp || ! copy( $file, $temp ) ) { throw new RuntimeException( __( 'Cannot copy images. Check your hosting upload-folder permissions.', 'cedarmillco' ) ); }
			$id = media_handle_sideload( array( 'name' => sanitize_file_name( $image['file'] ), 'tmp_name' => $temp ), 0, $image['alt'] );
			if ( is_wp_error( $id ) ) {
				if ( file_exists( $temp ) ) { wp_delete_file( $temp ); }
				throw new RuntimeException( $id->get_error_message() );
			}
			update_post_meta( $id, '_cm_starter_key', $key );
			update_post_meta( $id, '_wp_attachment_image_alt', sanitize_text_field( $image['alt'] ) );
		}
		$refs[ '@image:' . $image['key'] ] = $id;
	}
	$page_ids = array();
	foreach ( $data['pages'] as $slug => $title ) {
		$existing = get_page_by_path( $slug );
		if ( $existing && 'publish' === $existing->post_status ) { $page_id = $existing->ID; } else {
			$page_id = cedarmillco_seed_post( 'page', $title, 'page-' . $slug, array(), array( 'post_name' => $slug, 'post_content' => '<!-- wp:paragraph --><p>' . esc_html__( 'Page content is being prepared. Please contact Cedar Mill Co. for information.', 'cedarmillco' ) . '</p><!-- /wp:paragraph -->' ) );
		}
		$page_ids[ $slug ] = $page_id;
		$refs[ '@page:' . $slug ] = get_permalink( $page_id );
	}
	foreach ( $data['items'] as $item ) {
		$id = cedarmillco_seed_post( 'cm_item', $item['title'], 'item-' . $item['key'], cedarmillco_seed_resolve( $item['fields'], $refs ) );
		$refs[ '@item:' . $item['key'] ] = $id;
	}
	$section_ids = array();
	foreach ( $data['sections'] as $section ) {
		$section_ids[] = cedarmillco_seed_post( 'cm_section', $section['title'], 'section-' . $section['key'], cedarmillco_seed_resolve( $section['fields'], $refs ) );
	}
	$settings_id = cedarmillco_seed_post( 'cm_settings', 'Cedar Mill Co. — Header & Footer', 'site-settings', cedarmillco_seed_resolve( $data['settings'], $refs ), array( 'post_status' => 'private' ) );
	update_option( 'cedarmillco_settings_id', $settings_id, false );
	$home_id = cedarmillco_seed_post( 'page', 'Home — Cedar Mill Co.', 'homepage', array( 'cm_home_editor' => 'sections', 'cm_home_sections' => $section_ids ), array( 'post_name' => 'cedar-mill-home' ) );
	update_option( 'cedarmillco_home_id', $home_id, false );
	$refs['@home'] = get_permalink( $home_id );
	if ( $set_home ) {
		// Preserve previous reading settings for an administrator to restore if desired.
		if ( false === get_option( 'cedarmillco_previous_reading', false ) ) {
			add_option( 'cedarmillco_previous_reading', array( 'show_on_front' => get_option( 'show_on_front' ), 'page_on_front' => get_option( 'page_on_front' ) ), '', false );
		}
		update_option( 'show_on_front', 'page' );
		update_option( 'page_on_front', $home_id );
		$refs['@home'] = home_url( '/' );
	}
	$menu_id = absint( get_option( 'cedarmillco_starter_menu' ) );
	if ( ! $menu_id || ! wp_get_nav_menu_object( $menu_id ) ) {
		$created = wp_create_nav_menu( 'Cedar Mill Main — ' . $home_id );
		if ( is_wp_error( $created ) ) { throw new RuntimeException( $created->get_error_message() ); }
		$menu_id = $created;
		update_option( 'cedarmillco_starter_menu', $menu_id, false );
	}
	$parents = array();
	$existing_items = wp_get_nav_menu_items( $menu_id );
	foreach ( $data['menu'] as $position => $entry ) {
		list( $label, $reference, $parent ) = $entry;
		$object_id = '@home' === $reference ? $home_id : ( $page_ids[ str_replace( '@page:', '', $reference ) ] ?? 0 );
		$match_id = 0;
		foreach ( is_array( $existing_items ) ? $existing_items : array() as $existing_item ) {
			if ( (int) $existing_item->object_id === (int) $object_id ) { $match_id = $existing_item->ID; break; }
		}
		$menu_item = $match_id ? $match_id : wp_update_nav_menu_item( $menu_id, 0, array( 'menu-item-title' => $label, 'menu-item-object' => 'page', 'menu-item-object-id' => $object_id, 'menu-item-type' => 'post_type', 'menu-item-status' => 'publish', 'menu-item-parent-id' => $parent ? ( $parents[ $parent ] ?? 0 ) : 0, 'menu-item-position' => $position + 1 ) );
		if ( is_wp_error( $menu_item ) ) { throw new RuntimeException( $menu_item->get_error_message() ); }
		$parents[ $label ] = $menu_item;
	}
	if ( $set_menu ) {
		$locations = get_theme_mod( 'nav_menu_locations', array() );
		if ( false === get_option( 'cedarmillco_previous_primary_menu', false ) ) { add_option( 'cedarmillco_previous_primary_menu', absint( $locations['primary'] ?? 0 ), '', false ); }
		$locations['primary'] = $menu_id;
		set_theme_mod( 'nav_menu_locations', $locations );
	}
	return true;
}
