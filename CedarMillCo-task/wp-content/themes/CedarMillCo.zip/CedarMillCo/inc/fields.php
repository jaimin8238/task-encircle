<?php
/** Single field-schema source: bundled JSON, registered automatically. @package CedarMillCo */
defined( 'ABSPATH' ) || exit;

function cedarmillco_register_fields() {
	if ( ! function_exists( 'acf_add_local_field_group' ) ) {
		return;
	}
	foreach ( glob( get_template_directory() . '/acf-json/group_cm_*.json' ) as $file ) {
		$group = json_decode( file_get_contents( $file ), true ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
		if ( is_array( $group ) && isset( $group['key'], $group['fields'] ) ) {
			acf_add_local_field_group( $group );
		}
	}
}
add_action( 'acf/init', 'cedarmillco_register_fields' );
