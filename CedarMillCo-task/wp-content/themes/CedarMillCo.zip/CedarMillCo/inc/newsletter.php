<?php
/** Private local subscriber storage. No outbound email or provider sync. @package CedarMillCo */
defined( 'ABSPATH' ) || exit;

function cedarmillco_signup_redirect( $status ) {
	$referer = wp_get_referer();
	$url     = wp_validate_redirect( $referer ? $referer : '', home_url( '/' ) );
	$url     = remove_query_arg( 'cm_signup', $url );
	wp_safe_redirect( add_query_arg( 'cm_signup', sanitize_key( $status ), $url ), 303 );
	exit;
}

function cedarmillco_subscribe() {
	if ( 'POST' !== ( $_SERVER['REQUEST_METHOD'] ?? '' ) ) {
		cedarmillco_signup_redirect( 'error' );
	}
	$id = isset( $_POST['section_id'] ) && is_scalar( $_POST['section_id'] ) ? absint( $_POST['section_id'] ) : 0;
	$nonce = isset( $_POST['cm_subscribe_nonce'] ) && is_string( $_POST['cm_subscribe_nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['cm_subscribe_nonce'] ) ) : '';
	if ( ! wp_verify_nonce( $nonce, 'cedarmillco_subscribe_' . $id ) || 'cm_section' !== get_post_type( $id ) || 'publish' !== get_post_status( $id ) || 'newsletter' !== cedarmillco_text( 'cm_section_layout', $id ) || ! cedarmillco_field( 'cm_newsletter_enabled', $id ) || cedarmillco_field( 'cm_section_hidden', $id ) ) {
		cedarmillco_signup_redirect( 'error' );
	}
	if ( ! empty( $_POST['cm_website'] ) ) {
		cedarmillco_signup_redirect( 'success' );
	}
	$email = isset( $_POST['cm_email'] ) && is_string( $_POST['cm_email'] ) ? sanitize_email( wp_unslash( $_POST['cm_email'] ) ) : '';
	if ( ! is_email( $email ) || strlen( $email ) > 254 || ! isset( $_POST['cm_consent'] ) || '1' !== $_POST['cm_consent'] ) {
		cedarmillco_signup_redirect( 'error' );
	}
	$ip = isset( $_SERVER['REMOTE_ADDR'] ) && is_string( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : 'unknown';
	$rate_key = 'cm_signup_' . substr( wp_hash( $ip ), 0, 32 );
	if ( get_transient( $rate_key ) ) {
		cedarmillco_signup_redirect( 'error' );
	}
	set_transient( $rate_key, 1, MINUTE_IN_SECONDS );
	$email = strtolower( $email );
	$slug  = 'subscriber-' . hash( 'sha256', $email );
	$existing = get_posts( array( 'post_type' => 'cm_subscriber', 'post_status' => array( 'private', 'publish', 'draft' ), 'name' => $slug, 'numberposts' => 1, 'fields' => 'ids' ) );
	if ( ! $existing ) {
		$saved = wp_insert_post( array(
			'post_type' => 'cm_subscriber', 'post_status' => 'private', 'post_title' => $email, 'post_name' => $slug,
			'meta_input' => array( '_cm_signup_time' => current_time( 'mysql', true ), '_cm_signup_section' => $id, '_cm_signup_consent' => cedarmillco_text( 'cm_newsletter_consent_label', $id ) ),
		), true );
		if ( is_wp_error( $saved ) ) {
			delete_transient( $rate_key );
			cedarmillco_signup_redirect( 'error' );
		}
	}
	cedarmillco_signup_redirect( 'success' );
}
add_action( 'admin_post_nopriv_cedarmillco_subscribe', 'cedarmillco_subscribe' );
add_action( 'admin_post_cedarmillco_subscribe', 'cedarmillco_subscribe' );
