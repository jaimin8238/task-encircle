<?php
/** Safe content helpers. @package CedarMillCo */
defined( 'ABSPATH' ) || exit;

function cedarmillco_field( $name, $post_id = false ) {
	return function_exists( 'get_field' ) ? get_field( $name, $post_id ) : null;
}

function cedarmillco_text( $name, $post_id = false ) {
	$value = cedarmillco_field( $name, $post_id );
	return is_scalar( $value ) ? (string) $value : '';
}

function cedarmillco_settings_id() {
	$id = absint( get_option( 'cedarmillco_settings_id' ) );
	return 'cm_settings' === get_post_type( $id ) ? $id : 0;
}

function cedarmillco_setting( $name ) {
	$id = cedarmillco_settings_id();
	return $id ? cedarmillco_field( $name, $id ) : null;
}

function cedarmillco_related( $name, $post_id, $post_type = 'cm_item' ) {
	if ( ! $post_id ) { return array(); }
	$items = cedarmillco_field( $name, $post_id );
	$result = array();
	foreach ( is_array( $items ) ? $items : array() as $item ) {
		$id = is_object( $item ) ? absint( $item->ID ) : absint( $item );
		if ( $post_type === get_post_type( $id ) && 'publish' === get_post_status( $id ) ) {
			$result[] = $id;
		}
	}
	return $result;
}

function cedarmillco_image( $value, $size = 'large', $class = '', $eager = false ) {
	$id = is_array( $value ) ? absint( $value['ID'] ?? 0 ) : absint( $value );
	if ( ! $id || ! wp_attachment_is_image( $id ) ) {
		return;
	}
	$attributes = array( 'class' => $class, 'loading' => $eager ? 'eager' : 'lazy', 'decoding' => 'async' );
	if ( $eager ) {
		$attributes['fetchpriority'] = 'high';
	}
	// WordPress escapes attachment attributes and generates responsive srcset/sizes.
	echo wp_get_attachment_image( $id, $size, false, $attributes ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
}

function cedarmillco_link( $link, $class = 'text-link' ) {
	if ( ! is_array( $link ) || empty( $link['url'] ) || empty( $link['title'] ) || ! esc_url( $link['url'] ) ) {
		return;
	}
	$new_tab = '_blank' === ( $link['target'] ?? '' );
	?>
	<a class="<?php echo esc_attr( $class ); ?>" href="<?php echo esc_url( $link['url'] ); ?>"<?php if ( $new_tab ) : ?> target="_blank" rel="noopener noreferrer"<?php endif; ?>><?php echo esc_html( $link['title'] ); ?></a>
	<?php
}

function cedarmillco_eyebrow( $value ) {
	if ( $value ) {
		echo '<p class="eyebrow">' . esc_html( $value ) . '</p>';
	}
}

function cedarmillco_heading( $value, $tag = 'h2', $class = '' ) {
	$tag = in_array( $tag, array( 'h1', 'h2', 'h3' ), true ) ? $tag : 'h2';
	if ( $value ) {
		echo '<' . esc_attr( $tag ) . ' class="' . esc_attr( $class ) . '">' . esc_html( $value ) . '</' . esc_attr( $tag ) . '>';
	}
}

function cedarmillco_rich_text( $value, $class = 'prose' ) {
	if ( is_string( $value ) && trim( wp_strip_all_tags( $value ) ) ) {
		echo '<div class="' . esc_attr( $class ) . '">' . wp_kses_post( wpautop( $value ) ) . '</div>';
	}
}

function cedarmillco_layouts() {
	return array(
		'hero' => __( '01 · Hero', 'cedarmillco' ),
		'intro' => __( '02 · Intro Statement', 'cedarmillco' ),
		'products' => __( '03 · Product Categories', 'cedarmillco' ),
		'values' => __( '04 · Every Detail — Value Propositions', 'cedarmillco' ),
		'project' => __( '05 · Featured Project', 'cedarmillco' ),
		'cta' => __( '06 · CTA Band', 'cedarmillco' ),
		'newsletter' => __( '07 · Newsletter', 'cedarmillco' ),
		'instagram' => __( '08 · Instagram Grid', 'cedarmillco' ),
	);
}

function cedarmillco_render_section( $section_id, $expected_layout = '' ) {
	$section_id = absint( $section_id );
	if ( 'cm_section' !== get_post_type( $section_id ) || 'publish' !== get_post_status( $section_id ) || ! function_exists( 'get_field' ) ) {
		return;
	}
	$layout = cedarmillco_text( 'cm_section_layout', $section_id );
	if ( ! isset( cedarmillco_layouts()[ $layout ] ) || ( $expected_layout && $expected_layout !== $layout ) || cedarmillco_field( 'cm_section_hidden', $section_id ) ) {
		return;
	}
	// Whitelist prevents arbitrary template includes. Pass IDs; do not change global post state.
	get_template_part( 'template-parts/sections/' . $layout, null, array( 'section_id' => $section_id ) );
}
