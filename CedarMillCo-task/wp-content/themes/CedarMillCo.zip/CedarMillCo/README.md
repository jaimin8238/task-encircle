# CedarMillCo — START HERE

Works with your existing local WordPress and **Advanced Custom Fields (free)**. You do not need ACF Pro, Elementor, a page builder, Node, Composer, or another WordPress installation.

## 1. Copy the theme

1. Extract `CedarMillCo.zip`.
2. Copy the extracted **CedarMillCo** folder into your existing WordPress installation’s `wp-content/themes/` folder.
3. The final path must be `wp-content/themes/CedarMillCo/style.css`. Avoid an extra nested CedarMillCo folder.
4. Open your own local WordPress dashboard.
5. Go to **Appearance → Themes → CedarMillCo → Activate**.
6. Make sure your existing **Advanced Custom Fields** plugin is activated under Plugins.

Optional activation command, only if you already use WP-CLI: `wp theme activate CedarMillCo`.

## 2. Load the editable design

1. Open **Appearance → Cedar Mill Setup**.
2. Leave “Set the new Cedar Mill page as my site homepage” selected if you want this design as the front page. This changes Settings → Reading; it preserves your old page.
3. Leave the Main Navigation checkbox selected to assign the new nested menu. Existing menus are preserved.
4. Click **Create Starter Site** once. Wait for it to finish.
5. Visit your local website’s homepage.

This creates the eight homepage sections, reusable cards and buttons, site settings, an ordered homepage, a nested WordPress menu and Media Library images. All ACF fields register automatically: **do not create or import the fields manually**. Setup does not run just because you activate the theme and it does not overwrite your existing pages. If matching published destination pages already exist, their content is retained. Newly created destination pages contain editable placeholder text; this package implements the shared header/footer and full homepage, not complete inner-page designs.

## 3. Edit text and pictures

Open **Cedar Sections** in the dashboard. Click the section you want, change its ACF fields and click **Update**.

| Section | Content to edit |
| --- | --- |
| Home — Hero | Location line, headline, description, background photo and selected buttons |
| Home — Intro | Small label, heading and description |
| Home — Products | Heading, View All link and selected product cards |
| Home — Values | Heading, description, link and selected value propositions |
| Home — Project | Project photo, heading, description and button |
| Home — Cta | Small label, heading, description and button |
| Home — Newsletter | Heading, description, form labels, consent text and feedback messages |
| Home — Instagram | Heading, profile link, selected static images and caption |

To replace an image, choose the image field, select or upload a file, add appropriate alternative text in Media Library and update the section. Hero and project photos should ideally be at least 2000 pixels wide. Original logo and photographs from your supplied design are already included and imported by setup.

Empty text is omitted, empty links do not produce clickable buttons, absent images produce a plain background, unpublished selections are omitted, and fully empty sections are skipped. The Hero “Use H1 Heading” switch should be enabled for only one section per page.

## 4. Reorder, add, remove or duplicate sections

1. Open **Pages → Home — Cedar Mill Co. → Edit**.
2. Keep **Homepage Editing Method = ACF section list**.
3. Find **Homepage Sections — Drag to Reorder**. Selected sections are on the right.
4. Drag those selected rows up or down, then update the page.
5. To remove a section from the homepage, click its minus icon. Its saved record is retained.
6. To create one, use **Cedar Sections → Add New**. Enter an admin title, choose **Section Layout**, fill its fields and **Publish**. Then select it in the homepage’s section list.
7. To duplicate one, hover over it in **Cedar Sections**, choose **Duplicate**, edit the new draft and **Publish**. Add the copy to the homepage list.
8. The “Hide This Section” switch temporarily hides a section everywhere it is selected.

## 5. Edit repeating cards, buttons, offices and images

Use **Cedar Items**. Each item has an **Item Type**. Choose Product Card, Value Proposition, Instagram Image, Office Location, Social Link or CTA Button. The matching fields appear automatically.

Create an item, fill its fields and Publish. Then select it in the corresponding section or Site Settings list. Drag selected rows on the right to reorder them. Lists show published items of the appropriate type only. There is no fixed limit on offices, product cards, social links or buttons.

A Link field needs both its URL and Link Text. For example, edit **Button — Explore Our Products** to change the hero’s first button. Product Card descriptions are displayed as short uppercase captions. Office descriptions support line breaks for street addresses.

Duplicated sections initially reference the same selected items. Duplicate an item as well and select the copy when you want independent card/button content.

## 6. Edit the header and footer

Open **Cedar Site Settings**. The Brand, Header and Footer tabs contain company name, logos, top-bar text, optional header buttons, footer tagline, contact details, office selections, social selections and copyright.

Choose and update everything in this single record. Changes apply across the site. If a logo is cleared, the editable company name is used instead. Use `{year}` inside copyright to display the current year automatically. Header buttons are optional and empty in the starter to match the design.

## 7. Edit the navigation

Open **Appearance → Menus**. Select the Cedar Mill Main menu and keep it assigned to **Main Navigation**. Drag an item slightly to the right beneath Products or Projects to create a dropdown. Further indentation creates additional nested levels. Save Menu. Mobile navigation has separate submenu buttons so parent page links remain usable.

## 8. Use the eight WordPress blocks (optional)

You can use WordPress’s own block editor instead of the homepage section list. No paid ACF Blocks feature is used.

1. Create and publish section records in Cedar Sections first.
2. Edit the homepage and change **Homepage Editing Method** to **Native WordPress blocks**.
3. In the page’s main editor, press **+**, find the **Cedar Mill Co.** category and insert Hero, Intro Statement, Product Categories, Every Detail, Featured Project, CTA Band, Newsletter or Instagram Grid.
4. Select the matching published section from the block dropdown. **Edit ACF content** opens that section’s field editor.
5. Use WordPress’s toolbar to move, duplicate or remove blocks. Update the page.
6. Reload the page editor after creating new section records so its dropdowns refresh.

A duplicated block points to the same section record. To change its content independently, duplicate the section in Cedar Sections, publish it and select that copy in the block. Section-list mode and block mode are alternatives; only the selected method renders. Other regular pages support these blocks too.

## 9. Newsletter and Instagram

Newsletter signups are saved privately under **Newsletter Subscribers**, visible to administrators. The form checks consent, email validity and a security token, includes a hidden spam trap and limits repeat submissions. It **does not send emails, campaigns or sync with HubSpot/Mailchimp**. Remove an entry using WordPress’s normal Trash action when needed. If you later use a cache plugin, ensure the form’s security token is refreshed within its validity period.

Instagram uses editable static images only; no live feed, API key or external Instagram request is required to render the images. Optional profile links open Instagram when clicked.

## 10. What each folder does

- `functions.php`: loads the theme’s PHP modules.
- `header.php` / `footer.php`: shared ACF-driven header and footer.
- `front-page.php`: homepage rendering and editing-method selection.
- `page.php`, `single.php`, `index.php`, `404.php`: ordinary WordPress fallback templates.
- `template-parts/sections/`: one PHP template for each of the eight layouts.
- `acf-json/`: all 12 named ACF field groups, registered automatically by `inc/fields.php`.
- `blocks/`: eight native WordPress block definitions.
- `inc/`: setup, safe rendering helpers, content types, blocks, newsletter handling, admin controls and starter importer.
- `assets/css/reference.css`: your supplied stylesheet, with its remote font import replaced by local fonts.
- `assets/css/main.css`: WordPress markup, responsive and accessibility adapters.
- `assets/js/`: working nested menus and the native block editor controls. No build step.
- `assets/images/`: original design photos and logo, used only by the optional starter importer.
- `assets/fonts/`: self-hosted fonts and their open font license files.
- `FIELD-MAP.md`: every field label, field name, type and registered block name.
- `reference/`: original JavaScript retained as developer reference; it is not enqueued because its forms were design previews.

## Troubleshooting

**Theme is missing:** check the folder path from step 1 and confirm style.css is directly inside CedarMillCo.

**Fields are missing:** activate Advanced Custom Fields, then open a Cedar Section or Cedar Site Settings record. The JSON fields are registered in code and may not appear as editable database field groups in the ACF Field Groups listing. They appear on the content edit screens. Do not import duplicate groups.

**Homepage is blank:** run Cedar Mill Setup. Confirm Settings → Reading uses a static homepage and selects Home — Cedar Mill Co.; make sure sections are published and selected. Check that section-list mode is selected, or that blocks are configured if using block mode.

**Item is missing from a list:** publish it and choose the correct Item Type.

**Navigation is absent:** assign the menu under Appearance → Menus → Manage Locations.

**Setup cannot import images:** check that your local WordPress uploads folder is writable. Setup reports an error and can retry without duplicating completed starter records.

**Links return 404:** visit Settings → Permalinks and click Save Changes. The destination pages are starter placeholders unless they already existed in your site.

Requirements: WordPress 6.5+, PHP 8.0+, ACF Free. Tested in a temporary WordPress 6.8 / PHP 8.3 environment with ACF Free 6.8.10. All 24 PHP files passed native PHP 8.3 syntax checks. Homepage rendering and valid/invalid newsletter submissions were checked. Responsive layouts were inspected at desktop and mobile widths; perform a final review on your own local WordPress with your installed plugins.

This free-ACF implementation replaces the original brief’s paid Flexible Content and Options Pages with reusable section records, ordered Relationship fields, a shared settings record and eight native WordPress blocks. It preserves the ability to add, remove, reorder and duplicate sections, using a different backend workflow.
