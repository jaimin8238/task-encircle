<?php
/** Missing page. @package CedarMillCo */
defined( 'ABSPATH' ) || exit;
get_header();
?>
<main id="main-content" class="container page-content" tabindex="-1">
	<h1><?php esc_html_e( 'Page not found', 'cedarmillco' ); ?></h1>
	<p><a class="text-link" href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'Return home', 'cedarmillco' ); ?></a></p>
	<?php get_search_form(); ?>
</main>
<?php get_footer(); ?>
