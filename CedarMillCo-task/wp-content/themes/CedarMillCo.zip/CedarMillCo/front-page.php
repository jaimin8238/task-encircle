<?php
/** Editable homepage. @package CedarMillCo */
defined( 'ABSPATH' ) || exit;
get_header();
?>
<main id="main-content" tabindex="-1">
	<?php
	if ( have_posts() ) {
		the_post();
		if ( ! function_exists( 'get_field' ) || 'blocks' === cedarmillco_text( 'cm_home_editor', get_the_ID() ) ) {
			the_content();
		} else {
			foreach ( cedarmillco_related( 'cm_home_sections', get_the_ID(), 'cm_section' ) as $section_id ) {
				cedarmillco_render_section( $section_id );
			}
		}
	}
	?>
</main>
<?php get_footer(); ?>
